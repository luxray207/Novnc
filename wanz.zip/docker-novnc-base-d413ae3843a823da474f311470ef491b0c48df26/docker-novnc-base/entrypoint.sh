#!/bin/bash

set -e

shopt -s nullglob

# Cleanup lock/pid
rm -f /tmp/.X1-lock /tmp/.X11-unix/X1

kill_pid() {
  [ -f "$1" ] && kill $(cat "$1") 2>/dev/null && rm -f "$1"
}
kill_pid ~/.vnc-pid
kill_pid ~/.pa-pid
kill_pid ~/.tcp-pid
kill_pid ~/.ws-pid

# Set defaults
USERNAME=${USERNAME:-novnc}
UUID=${UUID:-1000}
GUID=${GUID:-1000}
VNC_PASSWORD=${VNC_PASSWORD:-novnc}
DISPLAY_RESOLUTION=${DISPLAY_RESOLUTION:-1280x720}
NOVNC_PORT=${NOVNC_PORT:-8080}

# Create user
if ! id -u "$USERNAME" >/dev/null 2>&1; then
  groupadd -g "$GUID" "$USERNAME"
  useradd -u "$UUID" -g "$GUID" -m -s /bin/bash "$USERNAME"
  echo "$USERNAME ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers
fi

# Switch to user and start services
sudo -u "$USERNAME" bash <<EOF
cd ~

# Buat password VNC
mkdir -p ~/.vnc
echo "$VNC_PASSWORD" | vncpasswd -f > ~/.vnc/passwd
chmod 600 ~/.vnc/passwd

# Start VNC Server
vncserver :1 -geometry $DISPLAY_RESOLUTION -SecurityTypes VncAuth -passwd ~/.vnc/passwd -localhost no &
echo \$! > ~/.vnc-pid

# Start PulseAudio
DISPLAY=:0.0 pulseaudio --disallow-module-loading --disallow-exit --exit-idle-time=-1 &
echo \$! > ~/.pa-pid

# Stream audio ke port 6901
tcpserver localhost 6901 gst-launch-1.0 -q pulsesrc server=/tmp/pulseaudio.socket ! audio/x-raw,channels=2,rate=12000 ! cutter ! opusenc ! webmmux ! fdsink fd=1 &
echo \$! > ~/.tcp-pid

# Token config
mkdir -p /opt/noVNC/token
echo "vnc: localhost:5901" > /opt/noVNC/token/tokenfile
echo "pulse: localhost:6901" >> /opt/noVNC/token/tokenfile

# Jalankan Websockify (NoVNC)
/opt/noVNC/utils/websockify/websockify.py \
  --web /opt/noVNC \
  --cert /opt/noVNC/utils/websockify/self.pem \
  --token-plugin TokenFile \
  --token-source /opt/noVNC/token/tokenfile \
  $NOVNC_PORT &
echo \$! > ~/.ws-pid

wait
EOF